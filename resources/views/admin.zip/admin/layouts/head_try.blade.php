
<meta charset="UTF-8">  
<meta name="_token" content="{{ csrf_token() }}"/>
<title> @yield('title') &#8211; Friending</title>
<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
<link href="{{ asset('css/admin/css/app.css') }}" rel="stylesheet" type="text/css" />
<!--page level css -->
<!--<link href="{{ asset('css/admin/vendors/fullcalendar/css/fullcalendar.css') }}" rel="stylesheet" type="text/css" />-->
<!--<link href="{{ asset('css/admin/css/pages/calendar_custom.css') }}" rel="stylesheet" type="text/css" />-->
<!--<link rel="stylesheet" media="all" href="{{ asset('css/admin/vendors/bower-jvectormap/css/jquery-jvectormap-1.2.2.css') }}" />-->
<!--<link rel="stylesheet" href="{{ asset('css/admin/vendors/animate/animate.min.css') }}">-->
<!--<link rel="stylesheet" type="text/css" href="{{ asset('css/admin/vendors/datetimepicker/css/bootstrap-datetimepicker.min.css') }}">-->
<!--<link rel="stylesheet" href="{{ asset('css/admin/css/pages/only_dashboard.css') }}" />-->
<!--end of page level css-->
<!--end  show data in table -->
<!-- end form add/edit -->
<link rel="stylesheet" href="{{ asset('css/admin/friend.css') }}">