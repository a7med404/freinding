$(document).ready(function () {
    var url = $('body').attr('data-url');

    var user_id = $('body').attr('data-user');

    var login_url = url + '/login';

    var login_register = url + '/register';

    var loader = '';
    if ($(window).width() < 800) {
        $('body').find('.main-sidebar').addClass('hide');
    }

//*********************************validation register*******************************************************
    $('body').on('change', '.check_password_confirm', function () {
        var obj = $(this);
        var user_pass2 = obj.val();
        var user_pass = $('body').find('.user_pass_buy').val();
        var comment_error_pass = $('.user_error_pass');
        comment_error_pass.addClass('hide');
        if (user_pass == user_pass2) {
            $('.user_pass').removeClass('has-error');
            comment_error_pass.addClass('hide');
            $('.user_pass_buy').val(user_pass);
//            obj.val(user_pass);
        } else {
            $('.user_pass').addClass('has-error');
            comment_error_pass.removeClass('hide');
            comment_error_pass.html('Plz,Enter password match');
            obj.val("");
            $('.user_pass_buy').val("");
            $('.user_pass_buy').focus();
        }
        return false;
    });
    $('body').on('change', '.db_user_email_buy', function () {
        var obj = $(this);
        var user_email = obj.val();
        var comment_error_email = $('.user_error_emailss');
//        var comment_error_phone = $('.user_error_phone');
        comment_error_email.addClass('hide');
//        comment_error_phone.addClass('hide');
        var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
//        if (user_email == '' || re.test(user_email) != true) {
//            comment_error_email.removeClass('hide');
//            comment_error_email.html(email_not_correct);
//            $('.user_email_buy').focus();
//            return false;
//        }
        $.ajax({
            type: "post",
            url: url + '/check_found_email',
            data: {
                _token: $('meta[name="_token"]').attr('content'),
                user_email: user_email
            },
            cache: false,
            dataType: 'json',
            success: function (data) {
                if (data != "") {
//                if (data.trim() != "") {
                    var response = data.response;
                    if (response == 1) {
                        comment_error_email.addClass('hide');
                        $('.user_email_buy').val(user_email);
                        return false;
                    } else if (response == 2) {
                        comment_error_email.removeClass('hide');
                        comment_error_email.html('( ' + user_email + ' ) ' + 'email_not_correct' + '');
                        $('.user_email_buy').val(" ");
                        $('.db_user_email_buy').focus();
                        return false;
                    } else {
                        comment_error_email.removeClass('hide');
                        comment_error_email.html('( ' + user_email + ' ) ' + 'email_already_use' + '');
                        $('.user_email_buy').val(" ");
                        $('.db_user_email_buy').focus();
                        return false;
                    }

                }
            },
            complete: function (data) {
                return false;
            }});
        return false;
    });
    $('body').on('change', '.db_user_phone_buy', function () {
        var obj = $(this);
        var user_phone = obj.val();
        var comment_error_phone = $('.user_error_phone');
//        comment_error_email.addClass('hide');
        comment_error_phone.addClass('hide');
        $('.user_pass').removeClass('has-error');
        if (typeof user_phone == 'undefined' || user_phone == '' || user_phone == "") {
            comment_error_phone.removeClass('hide');
            $('.user_pass').addClass('has-error');
            comment_error_phone.html('please_phone_correct');
            $('.db_user_phone_buy').focus();
            return false;
        }
        if (user_phone == 0 || user_phone == "0" || user_phone == '0') {
            return false;
        }
        $.ajax({
            type: "post",
            url: url + '/check_found_phone',
            data: {
                _token: $('meta[name="_token"]').attr('content'),
                user_phone: user_phone
            },
            cache: false,
            dataType: 'json',
            success: function (data) {
                if (data != "") {
//              if (data.trim() != "") {
                    var response = data.response;
                    if (response == 1) {
                        comment_error_phone.addClass('hide');
                        $('.user_phone_buy').val(user_phone);
                        return false;
                    } else if (response == 2) {
                        comment_error_phone.removeClass('hide');
                        comment_error_phone.html('( ' + user_phone + ' )  ' + 'please_phone_correct' + '');
                        $('.user_phone_buy').val(" ");
                        $('.db_user_phone_buy').focus();
                        return false;
                    } else {
                        comment_error_phone.removeClass('hide');
                        comment_error_phone.html('( ' + user_phone + ' )  ' + 'phone_number_already_used' + '');
                        $('.user_phone_buy').val(" ");
                        $('.db_user_phone_buy').focus();
                        return false;
                    }
                }
            },
            complete: function (data) {
                return false;
            }});
        return false;
    });
    // add frist step to buy if not register
    $('body').on('click', '.btnCheck_basic_inform', function () {
        var obj = $(this);
        var user_name = $('body').find('.user_name_buy').val();
        var display_name = $('body').find('.user_display_name').val();
        var user_birth = $('body').find('.user_birth_date').val();
        var user_email = $('body').find('.user_email_buy').val();
        var user_phone = $('body').find('.user_phone_buy').val();
        var user_pass = $('body').find('.user_pass_buy').val();
        var user_pass2 = $('body').find('.check_password_confirm').val();
//        var user_country = $("#country option:selected").val();
        var comment_error_name = $('.user_error_name');
        var comment_error_email = $('.user_error_email');
        var comment_error_pass = $('.user_error_pass');
        var comment_error_phone = $('.user_error_phone');
        var comment_error_dispaly = $('.user_error_dispaly');
        var comment_error_birth = $('.user_error_birth');
        comment_error_pass.addClass('hide');
        comment_error_name.addClass('hide');
        comment_error_email.addClass('hide');
        comment_error_phone.addClass('hide');
        comment_error_dispaly.addClass('hide');
        comment_error_birth.addClass('hide');
        $('.user_name').removeClass('has-error');
        $('.user_dispaly').removeClass('has-error');
        $('.user_email').removeClass('has-error');
        $('.user_phone').removeClass('has-error');
        $('.user_birth').removeClass('has-error');
        $('.user_pass').removeClass('has-error');
        if (typeof user_name == 'undefined' || user_name == '' || user_name == "") {
            comment_error_name.removeClass('hide');
            if (!comment_error_email.hasClass('hide')) {
                comment_error_email.addClass('hide');
            }
            if (!comment_error_pass.hasClass('hide')) {
                comment_error_pass.addClass('hide');
            }
            if (!comment_error_phone.hasClass('hide')) {
                comment_error_phone.addClass('hide');
            }
            if (!comment_error_birth.hasClass('hide')) {
                comment_error_birth.addClass('hide');
            }
            if (!comment_error_dispaly.hasClass('hide')) {
                comment_error_dispaly.addClass('hide');
                comment_error_dispaly.addClass('hide');
            }
            $('.user_name').addClass('has-error');
            comment_error_name.html('please enter username');
            $('.user_name_buy').focus();
            return false;
        }
        if (typeof display_name == 'undefined' || display_name == '' || display_name == "") {
            comment_error_name.removeClass('hide');
            if (!comment_error_email.hasClass('hide')) {
                comment_error_email.addClass('hide');
            }
            if (!comment_error_pass.hasClass('hide')) {
                comment_error_pass.addClass('hide');
            }
            if (!comment_error_phone.hasClass('hide')) {
                comment_error_phone.addClass('hide');
            }
            if (!comment_error_birth.hasClass('hide')) {
                comment_error_birth.addClass('hide');
            }
            if (!comment_error_name.hasClass('hide')) {
                comment_error_name.addClass('hide');
                comment_error_name.addClass('hide');
            }
            $('.user_dispaly').addClass('has-error');
            comment_error_name.html('please enter dispaly name');
            $('.user_name_dispaly').focus();
            return false;
        }
        var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (typeof user_email == 'undefined' || user_email == '' || re.test(user_email) != true) {
            comment_error_email.removeClass('hide');
            if (!comment_error_pass.hasClass('hide')) {
                comment_error_pass.addClass('hide');
            }
            if (!comment_error_name.hasClass('hide')) {
                comment_error_name.addClass('hide');
            }
            if (!comment_error_dispaly.hasClass('hide')) {
                comment_error_dispaly.addClass('hide');
            }
            if (!comment_error_phone.hasClass('hide')) {
                comment_error_phone.addClass('hide');
            }
            if (!comment_error_birth.hasClass('hide')) {
                comment_error_birth.addClass('hide');
            }
            $('.user_email').addClass('has-error');
            comment_error_email.html('please enter correct email');
            $('.user_email_buy').val(" ");
            $('.db_user_email_buy').focus();
            return false;
        }
        var pho = /^[0-9]{8,16}$/; ///^(\+91-|\+91|0)?\d{10}$/
        if (typeof user_phone == 'undefined' || user_phone == '' || user_phone == "" || pho.test(user_phone) != true) {
            comment_error_phone.removeClass('hide');
            if (!comment_error_email.hasClass('hide')) {
                comment_error_email.addClass('hide');
            }
            if (!comment_error_pass.hasClass('hide')) {
                comment_error_pass.addClass('hide');
            }
            if (!comment_error_name.hasClass('hide')) {
                comment_error_name.addClass('hide');
            }
            if (!comment_error_birth.hasClass('hide')) {
                comment_error_birth.addClass('hide');
            }
            if (!comment_error_dispaly.hasClass('hide')) {
                comment_error_dispaly.addClass('hide');
            }
            $('.user_phone').addClass('has-error');
            comment_error_phone.html('please enter correct phone');
            $('.user_phone_buy').val(" ");
            $('.db_user_phone_buy').focus();
            return false;
        }
        if (user_pass != user_pass2) {
            comment_error_pass.removeClass('hide');
            if (!comment_error_email.hasClass('hide')) {
                comment_error_email.addClass('hide');
            }
            if (!comment_error_name.hasClass('hide')) {
                comment_error_name.addClass('hide');
            }
            if (!comment_error_phone.hasClass('hide')) {
                comment_error_phone.addClass('hide');
            }
            if (!comment_error_birth.hasClass('hide')) {
                comment_error_birth.addClass('hide');
            }
            if (!comment_error_dispaly.hasClass('hide')) {
                comment_error_dispaly.addClass('hide');
            }
            $('.user_pass').addClass('has-error');
            comment_error_pass.html('enter_password_match');
            obj.val("");
            $('.user_pass_buy').val("");
            $('.user_pass_buy').focus();
            return false;
        }
        if (typeof user_birth == 'undefined' || user_birth == '' || user_birth == "" || user_birth == 0 || user_birth == "0" || user_birth == '0') {
            comment_error_birth.removeClass('hide');
            if (!comment_error_email.hasClass('hide')) {
                comment_error_email.addClass('hide');
            }
            if (!comment_error_pass.hasClass('hide')) {
                comment_error_pass.addClass('hide');
            }
            if (!comment_error_name.hasClass('hide')) {
                comment_error_name.addClass('hide');
            }
            if (!comment_error_phone.hasClass('hide')) {
                comment_error_phone.addClass('hide');
            }
            if (!comment_error_dispaly.hasClass('hide')) {
                comment_error_dispaly.addClass('hide');
            }
            $('.user_birth').addClass('has-error');
            comment_error_birth.html('please Choose your Biirthdate');
            $('.user_birth_condition').focus();
            return false;
        }
        $('body').find('.submit_basic_inform').click();
        return false;
    });
    //*************************************
    $('body').on('click', '.sidebar-toggle', function () {
        if ($(window).width() < 800) {
            var found = $('body').find('.main-sidebar').hasClass("hide");
            if (found == 'true' || found == true) {
                $('body').find('.main-sidebar').removeClass('hide');
            } else {
                $('body').find('.main-sidebar').addClass('hide');
            }
            return false;
        }
    });
    $("body").on('change', '.ajax_get_subcategory', function () {
        var obj = $(this);
        var id = obj.val();
        $.ajax({
            type: "post",
            url: url + '/admin/courses/ajax_subcategory', // URL 
            data: {
                _token: $('meta[name="_token"]').attr('content'),
                id: id
            },
            cache: false,
            dataType: 'json',
            success: function (data) {
                if (data !== "") {
                    console.log(data.subcategories);
                    if (data.hasOwnProperty('subcategories')) {
                        $(".draw_get_subcategory").text('');
                        $('#draw_get_subcategory').html(data.subcategories); //5
                    }
                }
            },
            complete: function (data) {
            }});
        return false;
    });

});



