<?php
namespace App\Model;

use Zizaco\Entrust\EntrustPermission;

class Permission extends EntrustPermission

{

}
