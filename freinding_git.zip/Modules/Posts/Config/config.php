<?php

return [
    'name' => 'Posts'
];
