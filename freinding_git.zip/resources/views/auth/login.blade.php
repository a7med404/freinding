@extends('site.layouts.app')
@section('content')
@include('site.home.pagelogout')
@endsection

