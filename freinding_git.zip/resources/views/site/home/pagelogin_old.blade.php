@include('site.home.sideleft')
@include('site.home.sideright')
@include('site.layouts.header')
<div class="container">
    <div class="row">

        <div class="col col-xl-6 order-xl-2 col-lg-12 order-lg-1 col-sm-12 col-12">

            <div class="page-description">
                <div class="icon">
                    <svg class="olymp-star-icon left-menu-icon"  data-toggle="tooltip" data-placement="right"   data-original-title="FAV PAGE"><use xlink:href="svg-icons/sprites/icons.svg#olymp-star-icon"></use></svg>
                </div>
                <span>Here you’ll see the recent updates of your Fav Pages</span>
            </div>

            <div id="newsfeed-items-grid">
                <div class="ui-block">

                    <!-- Post -->

                    <article class="hentry post has-post-thumbnail">

                        <div class="post__author author vcard inline-items">
                            <img src="{{ asset('olympus/img/author-page.jpg') }}" alt="author">

                            <div class="author-date">
                                <a class="h6 post__author-name fn" href="02-ProfilePage.html">James Spiegel</a>
                                <div class="post__date">
                                    <time class="published" datetime="2017-03-24T18:18">
                                        7 hours ago
                                    </time>
                                </div>
                            </div>

                            <div class="more"><svg class="olymp-three-dots-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-three-dots-icon"></use></svg>
                                <ul class="more-dropdown">
                                    <li>
                                        <a href="#">Edit Post</a>
                                    </li>
                                    <li>
                                        <a href="#">Delete Post</a>
                                    </li>
                                    <li>
                                        <a href="#">Turn Off Notifications</a>
                                    </li>
                                    <li>
                                        <a href="#">Select as Featured</a>
                                    </li>
                                </ul>
                            </div>

                        </div>

                        <p>Check out the GIF of our photoshoot from the other day:</p>

                        <div class="post-thumb">
                            <img class="gif-play-image" data-mode="video" data-mp4="videos/post_video.mp4" src="{{ asset('olympus/img/post__thumb3.jpg') }}"  alt="gif">
                        </div>

                        <div class="post-additional-info inline-items">

                            <a href="#" class="post-add-icon inline-items">
                                <svg class="olymp-heart-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-heart-icon"></use></svg>
                                <span>15</span>
                            </a>

                            <ul class="friends-harmonic">
                                <li>
                                    <a href="#">
                                        <img src="{{ asset('olympus/img/friend-harmonic5.jpg') }}" alt="friend">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="{{ asset('olympus/img/friend-harmonic10.jpg') }}" alt="friend">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="{{ asset('olympus/img/friend-harmonic7.jpg') }}" alt="friend">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="{{ asset('olympus/img/friend-harmonic8.jpg') }}" alt="friend">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="{{ asset('olympus/img/friend-harmonic2.jpg') }}" alt="friend">
                                    </a>
                                </li>
                            </ul>

                            <div class="names-people-likes">
                                <a href="#">Diana</a>, <a href="#">Nicholas</a> and
                                <br>47 more liked this
                            </div>


                            <div class="comments-shared">
                                <a href="#" class="post-add-icon inline-items">
                                    <svg class="olymp-speech-balloon-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-speech-balloon-icon"></use></svg>
                                    <span>16</span>
                                </a>

                                <a href="#" class="post-add-icon inline-items">
                                    <svg class="olymp-share-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-share-icon"></use></svg>
                                    <span>0</span>
                                </a>
                            </div>


                        </div>

                        <div class="control-block-button post-control-button">

                            <a href="#" class="btn btn-control">
                                <svg class="olymp-like-post-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-like-post-icon"></use></svg>
                            </a>

                            <a href="#" class="btn btn-control">
                                <svg class="olymp-comments-post-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-comments-post-icon"></use></svg>
                            </a>

                            <a href="#" class="btn btn-control">
                                <svg class="olymp-share-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-share-icon"></use></svg>
                            </a>

                        </div>

                    </article>

                    <!-- ... end Post -->
                </div>

                <div class="ui-block">

                    <!-- Post -->

                    <article class="hentry post">

                        <div class="post__author author vcard inline-items">
                            <img src="{{ asset('olympus/img/avatar42-sm.jpg') }}" alt="author">

                            <div class="author-date">
                                <a class="h6 post__author-name fn" href="#">Tapronus Rock</a>
                                <div class="post__date">
                                    <time class="published" datetime="2017-03-24T18:18">
                                        54 mins ago
                                    </time>
                                </div>
                            </div>

                            <div class="more"><svg class="olymp-three-dots-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-three-dots-icon"></use></svg>
                                <ul class="more-dropdown">
                                    <li>
                                        <a href="#">Edit Post</a>
                                    </li>
                                    <li>
                                        <a href="#">Delete Post</a>
                                    </li>
                                    <li>
                                        <a href="#">Turn Off Notifications</a>
                                    </li>
                                    <li>
                                        <a href="#">Select as Featured</a>
                                    </li>
                                </ul>
                            </div>

                        </div>

                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempo incididunt ut
                            labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris consequat.
                        </p>

                        <div class="post-additional-info inline-items">

                            <a href="#" class="post-add-icon inline-items">
                                <svg class="olymp-heart-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-heart-icon"></use></svg>
                                <span>24</span>
                            </a>

                            <ul class="friends-harmonic">
                                <li>
                                    <a href="#">
                                        <img src="{{ asset('olympus/img/friend-harmonic7.jpg') }}" alt="friend">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="{{ asset('olympus/img/friend-harmonic8.jpg') }}" alt="friend">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="{{ asset('olympus/img/friend-harmonic9.jpg') }}" alt="friend">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="{{ asset('olympus/img/friend-harmonic10.jpg') }}" alt="friend">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="{{ asset('olympus/img/friend-harmonic11.jpg') }}" alt="friend">
                                    </a>
                                </li>
                            </ul>

                            <div class="names-people-likes">
                                <a href="#">You</a>, <a href="#">Elaine</a> and
                                <br>34 more liked this
                            </div>


                            <div class="comments-shared">
                                <a href="#" class="post-add-icon inline-items">
                                    <svg class="olymp-speech-balloon-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-speech-balloon-icon"></use></svg>
                                    <span>17</span>
                                </a>

                                <a href="#" class="post-add-icon inline-items">
                                    <svg class="olymp-share-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-share-icon"></use></svg>
                                    <span>24</span>
                                </a>
                            </div>


                        </div>

                        <div class="control-block-button post-control-button">

                            <a href="#" class="btn btn-control">
                                <svg class="olymp-like-post-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-like-post-icon"></use></svg>
                            </a>

                            <a href="#" class="btn btn-control">
                                <svg class="olymp-comments-post-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-comments-post-icon"></use></svg>
                            </a>

                            <a href="#" class="btn btn-control">
                                <svg class="olymp-share-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-share-icon"></use></svg>
                            </a>

                        </div>

                    </article>

                    <!-- ... end Post -->					
                    <!-- Comments -->

                    <ul class="comments-list">
                        <li class="comment-item">
                            <div class="post__author author vcard inline-items">
                                <img src="{{ asset('olympus/img/author-page.jpg') }}" alt="author">

                                <div class="author-date">
                                    <a class="h6 post__author-name fn" href="02-ProfilePage.html">James Spiegel</a>
                                    <div class="post__date">
                                        <time class="published" datetime="2004-07-24T18:18">
                                            38 mins ago
                                        </time>
                                    </div>
                                </div>

                                <a href="#" class="more"><svg class="olymp-three-dots-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-three-dots-icon"></use></svg></a>

                            </div>

                            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium der doloremque laudantium.</p>

                            <a href="#" class="post-add-icon inline-items">
                                <svg class="olymp-heart-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-heart-icon"></use></svg>
                                <span>3</span>
                            </a>
                            <a href="#" class="reply">Reply</a>
                        </li>
                        <li class="comment-item">
                            <div class="post__author author vcard inline-items">
                                <img src="{{ asset('olympus/img/avatar1-sm.jpg') }}" alt="author">

                                <div class="author-date">
                                    <a class="h6 post__author-name fn" href="#">Mathilda Brinker</a>
                                    <div class="post__date">
                                        <time class="published" datetime="2004-07-24T18:18">
                                            1 hour ago
                                        </time>
                                    </div>
                                </div>

                                <a href="#" class="more"><svg class="olymp-three-dots-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-three-dots-icon"></use></svg></a>

                            </div>

                            <p>Ratione voluptatem sequi en lod nesciunt. Neque porro quisquam est, quinder dolorem ipsum
                                quia dolor sit amet, consectetur adipisci velit en lorem ipsum duis aute irure dolor in reprehenderit in voluptate velit esse cillum.
                            </p>

                            <a href="#" class="post-add-icon inline-items">
                                <svg class="olymp-heart-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-heart-icon"></use></svg>
                                <span>8</span>
                            </a>
                            <a href="#" class="reply">Reply</a>
                        </li>
                    </ul>

                    <!-- ... end Comments -->

                    <a href="#" class="more-comments">View more comments <span>+</span></a>


                    <!-- Comment Form  -->

                    <form class="comment-form inline-items">

                        <div class="post__author author vcard inline-items">
                            <img src="{{ asset('olympus/img/author-page.jpg') }}" alt="author">

                            <div class="form-group with-icon-right ">
                                <textarea class="form-control" placeholder=""></textarea>
                                <div class="add-options-message">
                                    <a href="#" class="options-message" data-toggle="modal" data-target="#update-header-photo">
                                        <svg class="olymp-camera-icon">
                                        <use xlink:href="svg-icons/sprites/icons.svg#olymp-camera-icon"></use>
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <button class="btn btn-md-2 btn-primary">Post Comment</button>

                        <button class="btn btn-md-2 btn-border-think c-grey btn-transparent custom-color">Cancel</button>

                    </form>

                    <!-- ... end Comment Form  -->
                </div>

                <div class="ui-block">

                    <!-- Post -->

                    <article class="hentry post">

                        <div class="post__author author vcard inline-items">
                            <img src="{{ asset('olympus/img/avatar47-sm.jpg') }}" alt="author">

                            <div class="author-date">
                                <a class="h6 post__author-name fn" href="#">Blue Whale Pizzas</a> uploaded 16 <a href="#">new photos</a>
                                <div class="post__date">
                                    <time class="published" datetime="2017-03-24T18:18">
                                        7 hours ago
                                    </time>
                                </div>
                            </div>

                            <div class="more"><svg class="olymp-three-dots-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-three-dots-icon"></use></svg>
                                <ul class="more-dropdown">
                                    <li>
                                        <a href="#">Edit Post</a>
                                    </li>
                                    <li>
                                        <a href="#">Delete Post</a>
                                    </li>
                                    <li>
                                        <a href="#">Turn Off Notifications</a>
                                    </li>
                                    <li>
                                        <a href="#">Select as Featured</a>
                                    </li>
                                </ul>
                            </div>

                        </div>

                        <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia erunt mollit anim id
                            est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium.
                        </p>

                        <div class="post-block-photo js-zoom-gallery">
                            <a href="{{ asset('olympus/img/post-photo7.jpg') }}" class="half-width"><img src="{{ asset('olympus/img/post-photo7.jpg') }}" alt="photo"></a>
                            <a href="{{ asset('olympus/img/post-photo2.jpg') }}" class="half-width"><img src="{{ asset('olympus/img/post-photo2.jpg') }}" alt="photo"></a>
                            <a href="{{ asset('olympus/img/post-photo3.jpg') }}" class="col col-3-width"><img src="{{ asset('olympus/img/post-photo3.jpg') }}" alt="photo"></a>
                            <a href="{{ asset('olympus/img/post-photo4.jpg') }}" class="col col-3-width"><img src="{{ asset('olympus/img/post-photo4.jpg') }}" alt="photo"></a>
                            <a href="{{ asset('olympus/img/post-photo5.jpg') }}" class="more-photos col-3-width">
                                <img src="{{ asset('olympus/img/post-photo5.jpg') }}" alt="photo">
                                <span class="h2">+12</span>
                            </a>
                        </div>

                        <div class="post-additional-info inline-items">

                            <a href="#" class="post-add-icon inline-items">
                                <svg class="olymp-heart-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-heart-icon"></use></svg>
                                <span>0</span>
                            </a>

                            <div class="comments-shared">
                                <a href="#" class="post-add-icon inline-items">
                                    <svg class="olymp-speech-balloon-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-speech-balloon-icon"></use></svg>
                                    <span>0</span>
                                </a>

                                <a href="#" class="post-add-icon inline-items">
                                    <svg class="olymp-share-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-share-icon"></use></svg>
                                    <span>16</span>
                                </a>
                            </div>


                        </div>

                        <div class="control-block-button post-control-button">

                            <a href="#" class="btn btn-control">
                                <svg class="olymp-like-post-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-like-post-icon"></use></svg>
                            </a>

                            <a href="#" class="btn btn-control">
                                <svg class="olymp-comments-post-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-comments-post-icon"></use></svg>
                            </a>

                            <a href="#" class="btn btn-control">
                                <svg class="olymp-share-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-share-icon"></use></svg>
                            </a>

                        </div>

                    </article>

                    <!-- ... end Post -->				</div>

                <div class="ui-block">

                    <article class="hentry post has-post-thumbnail">

                        <div class="post__author author vcard inline-items">
                            <img src="{{ asset('olympus/img/avatar5-sm.jpg') }}" alt="author">

                            <div class="author-date">
                                <a class="h6 post__author-name fn" href="#">Green Goo Rock</a>
                                <div class="post__date">
                                    <time class="published" datetime="2004-07-24T18:18">
                                        March 8 at 6:42pm
                                    </time>
                                </div>
                            </div>

                            <div class="more"><svg class="olymp-three-dots-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-three-dots-icon"></use></svg>
                                <ul class="more-dropdown">
                                    <li>
                                        <a href="#">Edit Post</a>
                                    </li>
                                    <li>
                                        <a href="#">Delete Post</a>
                                    </li>
                                    <li>
                                        <a href="#">Turn Off Notifications</a>
                                    </li>
                                    <li>
                                        <a href="#">Select as Featured</a>
                                    </li>
                                </ul>
                            </div>

                        </div>

                        <p>Hey guys! We are gona be playing this Saturday of <a href="#">The Marina Bar</a> for their new Mystic Deer Party.
                            If you wanna hang out and have a really good time, come and join us. We’l be waiting for you!
                        </p>

                        <div class="post-thumb">
                            <img src="{{ asset('olympus/img/post__thumb1.jpg') }}" alt="photo">
                        </div>

                        <div class="post-additional-info inline-items">

                            <a href="#" class="post-add-icon inline-items">
                                <svg class="olymp-heart-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-heart-icon"></use></svg>
                                <span>49</span>
                            </a>

                            <ul class="friends-harmonic">
                                <li>
                                    <a href="#">
                                        <img src="{{ asset('olympus/img/friend-harmonic9.jpg') }}" alt="friend">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="{{ asset('olympus/img/friend-harmonic10.jpg') }}" alt="friend">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="{{ asset('olympus/img/friend-harmonic7.jpg') }}" alt="friend">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="{{ asset('olympus/img/friend-harmonic8.jpg') }}" alt="friend">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="{{ asset('olympus/img/friend-harmonic11.jpg') }}" alt="friend">
                                    </a>
                                </li>
                            </ul>

                            <div class="names-people-likes">
                                <a href="#">Jimmy</a>, <a href="#">Andrea</a> and
                                <br>47 more liked this
                            </div>


                            <div class="comments-shared">
                                <a href="#" class="post-add-icon inline-items">
                                    <svg class="olymp-speech-balloon-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-speech-balloon-icon"></use></svg>
                                    <span>264</span>
                                </a>

                                <a href="#" class="post-add-icon inline-items">
                                    <svg class="olymp-share-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-share-icon"></use></svg>
                                    <span>37</span>
                                </a>
                            </div>


                        </div>

                        <div class="control-block-button post-control-button">

                            <a href="#" class="btn btn-control">
                                <svg class="olymp-like-post-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-like-post-icon"></use></svg>
                            </a>

                            <a href="#" class="btn btn-control">
                                <svg class="olymp-comments-post-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-comments-post-icon"></use></svg>
                            </a>

                            <a href="#" class="btn btn-control">
                                <svg class="olymp-share-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-share-icon"></use></svg>
                            </a>

                        </div>

                    </article>
                </div>
            </div>

            <a id="load-more-button" href="#" class="btn btn-control btn-more" data-load-link="items-to-load.html" data-container="newsfeed-items-grid"><svg class="olymp-three-dots-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-three-dots-icon"></use></svg></a>

        </div>

        <div class="col col-xl-3 order-xl-1 col-lg-6 order-lg-2 col-md-6 col-sm-12 col-12">
            <div class="ui-block">
                <div class="ui-block-title">
                    <h6 class="title">Friend Suggestions</h6>
                    <a href="#" class="more"><svg class="olymp-three-dots-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-three-dots-icon"></use></svg></a>
                </div>



                <!-- W-Action -->

                <ul class="widget w-friend-pages-added notification-list friend-requests">
                    <li class="inline-items">
                        <div class="author-thumb">
                            <img src="{{ asset('olympus/img/avatar38-sm.jpg') }}" alt="author">
                        </div>
                        <div class="notification-event">
                            <a href="#" class="h6 notification-friend">Francine Smith</a>
                            <span class="chat-message-item">8 Friends in Common</span>
                        </div>
                        <span class="notification-icon">
                            <a href="#" class="accept-request">
                                <span class="icon-add without-text">
                                    <svg class="olymp-happy-face-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-happy-face-icon"></use></svg>
                                </span>
                            </a>
                        </span>
                    </li>

                    <li class="inline-items">
                        <div class="author-thumb">
                            <img src="{{ asset('olympus/img/avatar39-sm.jpg') }}" alt="author">
                        </div>
                        <div class="notification-event">
                            <a href="#" class="h6 notification-friend">Hugh Wilson</a>
                            <span class="chat-message-item">6 Friends in Common</span>
                        </div>
                        <span class="notification-icon">
                            <a href="#" class="accept-request">
                                <span class="icon-add without-text">
                                    <svg class="olymp-happy-face-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-happy-face-icon"></use></svg>
                                </span>
                            </a>
                        </span>
                    </li>

                    <li class="inline-items">
                        <div class="author-thumb">
                            <img src="{{ asset('olympus/img/avatar40-sm.jpg') }}" alt="author">
                        </div>
                        <div class="notification-event">
                            <a href="#" class="h6 notification-friend">Karen Masters</a>
                            <span class="chat-message-item">6 Friends in Common</span>
                        </div>
                        <span class="notification-icon">
                            <a href="#" class="accept-request">
                                <span class="icon-add without-text">
                                    <svg class="olymp-happy-face-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-happy-face-icon"></use></svg>
                                </span>
                            </a>
                        </span>
                    </li>

                </ul>

                <!-- ... end W-Action -->
            </div>

            <div class="ui-block">
                <div class="ui-block-title">
                    <h6 class="title">Pages You May Like</h6>
                    <a href="#" class="more"><svg class="olymp-three-dots-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-three-dots-icon"></use></svg></a>
                </div>

                <!-- W-Friend-Pages-Added -->

                <ul class="widget w-friend-pages-added notification-list friend-requests">
                    <li class="inline-items">
                        <div class="author-thumb">
                            <img src="{{ asset('olympus/img/avatar41-sm.jpg') }}" alt="author">
                        </div>
                        <div class="notification-event">
                            <a href="#" class="h6 notification-friend">The Marina Bar</a>
                            <span class="chat-message-item">Restaurant / Bar</span>
                        </div>
                        <span class="notification-icon" data-toggle="tooltip" data-placement="top" data-original-title="ADD TO YOUR FAVS">
                            <a href="#">
                                <svg class="olymp-star-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-star-icon"></use></svg>
                            </a>
                        </span>

                    </li>

                    <li class="inline-items">
                        <div class="author-thumb">
                            <img src="{{ asset('olympus/img/avatar42-sm.jpg') }}" alt="author">
                        </div>
                        <div class="notification-event">
                            <a href="#" class="h6 notification-friend">Tapronus Rock</a>
                            <span class="chat-message-item">Rock Band</span>
                        </div>
                        <span class="notification-icon" data-toggle="tooltip" data-placement="top" data-original-title="ADD TO YOUR FAVS">
                            <a href="#">
                                <svg class="olymp-star-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-star-icon"></use></svg>
                            </a>
                        </span>

                    </li>

                    <li class="inline-items">
                        <div class="author-thumb">
                            <img src="{{ asset('olympus/img/avatar43-sm.jpg') }}" alt="author">
                        </div>
                        <div class="notification-event">
                            <a href="#" class="h6 notification-friend">Pixel Digital Design</a>
                            <span class="chat-message-item">Company</span>
                        </div>
                        <span class="notification-icon" data-toggle="tooltip" data-placement="top" data-original-title="ADD TO YOUR FAVS">
                            <a href="#">
                                <svg class="olymp-star-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-star-icon"></use></svg>
                            </a>
                        </span>
                    </li>

                    <li class="inline-items">
                        <div class="author-thumb">
                            <img src="{{ asset('olympus/img/avatar44-sm.jpg') }}" alt="author">
                        </div>
                        <div class="notification-event">
                            <a href="#" class="h6 notification-friend">Thompson’s Custom Clothing Boutique</a>
                            <span class="chat-message-item">Clothing Store</span>
                        </div>
                        <span class="notification-icon" data-toggle="tooltip" data-placement="top" data-original-title="ADD TO YOUR FAVS">
                            <a href="#">
                                <svg class="olymp-star-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-star-icon"></use></svg>
                            </a>
                        </span>

                    </li>

                    <li class="inline-items">
                        <div class="author-thumb">
                            <img src="{{ asset('olympus/img/avatar45-sm.jpg') }}" alt="author">
                        </div>
                        <div class="notification-event">
                            <a href="#" class="h6 notification-friend">Crimson Agency</a>
                            <span class="chat-message-item">Company</span>
                        </div>
                        <span class="notification-icon" data-toggle="tooltip" data-placement="top" data-original-title="ADD TO YOUR FAVS">
                            <a href="#">
                                <svg class="olymp-star-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-star-icon"></use></svg>
                            </a>
                        </span>
                    </li>

                    <li class="inline-items">
                        <div class="author-thumb">
                            <img src="{{ asset('olympus/img/avatar46-sm.jpg') }}" alt="author">
                        </div>
                        <div class="notification-event">
                            <a href="#" class="h6 notification-friend">Mannequin Angel</a>
                            <span class="chat-message-item">Clothing Store</span>
                        </div>
                        <span class="notification-icon" data-toggle="tooltip" data-placement="top" data-original-title="ADD TO YOUR FAVS">
                            <a href="#">
                                <svg class="olymp-star-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-star-icon"></use></svg>
                            </a>
                        </span>
                    </li>
                </ul>

                <!-- .. end W-Friend-Pages-Added -->
            </div>

        </div>

        <div class="col col-xl-3 order-xl-3 col-lg-6 order-lg-3 col-md-6 col-sm-12 col-12">


            <div class="ui-block">

                <!-- W-Create-Fav-Page -->

                <div class="widget w-create-fav-page">
                    <div class="icons-block">
                        <svg class="olymp-star-icon left-menu-icon"  data-toggle="tooltip" data-placement="right"   data-original-title="FAV PAGE"><use xlink:href="svg-icons/sprites/icons.svg#olymp-star-icon"></use></svg>

                        <a href="#" class="more"><svg class="olymp-three-dots-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-three-dots-icon"></use></svg></a>
                    </div>

                    <div class="content">
                        <span>Be like them and</span>
                        <h3 class="title">Create your own Favourite Page!</h3>
                        <a href="36-FavPage-SettingsAndCreatePopup.html" class="btn btn-bg-secondary btn-sm">Start Now!</a>
                    </div>
                </div>

                <!-- ... end W-Create-Fav-Page -->			</div>

            <div class="ui-block">
                <div class="ui-block-title">
                    <h6 class="title">Your Fav Pages (54)</h6>
                    <a href="#" class="more"><svg class="olymp-three-dots-icon"><use xlink:href="svg-icons/sprites/icons.svg#olymp-three-dots-icon"></use></svg></a>
                </div>
                <div class="ui-block-content">

                    <!-- W-Faved-Page -->

                    <ul class="widget w-faved-page">
                        <li>
                            <a href="#">
                                <img src="{{ asset('olympus/img/avatar41-sm.jpg') }}" alt="author">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="{{ asset('olympus/img/faved-page7.jpg') }}" alt="user">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="{{ asset('olympus/img/avatar43-sm.jpg') }}" alt="author">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="{{ asset('olympus/img/faved-page7.jpg') }}" alt="user">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="{{ asset('olympus/img/avatar44-sm.jpg') }}" alt="author">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="{{ asset('olympus/img/avatar42-sm.jpg') }}" alt="author">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="{{ asset('olympus/img/faved-page7.jpg') }}" alt="user">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="{{ asset('olympus/img/avatar45-sm.jpg') }}" alt="author">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="{{ asset('olympus/img/avatar46-sm.jpg') }}" alt="author">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="{{ asset('olympus/img/faved-page7.jpg') }}" alt="user">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="{{ asset('olympus/img/faved-page1.jpg') }}" alt="user">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="{{ asset('olympus/img/faved-page11.jpg') }}" alt="user">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="{{ asset('olympus/img/faved-page7.jpg') }}" alt="user">
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <img src="{{ asset('olympus/img/faved-page12.jpg') }}" alt="user">
                            </a>
                        </li>
                        <li class="all-users">
                            <a href="#">+40</a>
                        </li>
                    </ul>

                    <!-- ... end W-Faved-Page -->				</div>
            </div>

        </div>

    </div>
</div>
@include('site.home.popup')





