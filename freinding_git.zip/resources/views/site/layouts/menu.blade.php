<li ><a href="{{ route('home') }}"> Home </a></li>
<!--this link test only-->
<li ><a href="{{ route('admin.index') }}">  Admin Panel </a></li>   
