<meta charset="UTF-8">  
<meta name="_token" content="{{ csrf_token() }}"/>
<title> @yield('title') &#8211; Friending</title>
<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
<link href="{{ asset('css/admin/css/app.css') }}" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="{{ asset('css/admin/friend.css') }}">