<!-- global js -->
<script src="{{ asset('js/admin/app.js') }}" type="text/javascript"></script>
    <script type="text/javascript" src="{{ asset('css/admin/vendors/datatables/js/jquery.dataTables.js') }}"></script>
    <script type="text/javascript" src="{{ asset('css/admin/vendors/datatables/js/dataTables.bootstrap.js') }}"></script>
    <script type="text/javascript" src="{{ asset('css/admin/vendors/datatables/js/dataTables.responsive.js') }}"></script>
    <script type="text/javascript" src="{{ asset('css/admin/vendors/select2/js/select2.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/admin/pages/table-advanced2.js') }}"></script>

<!--<script src="{{ asset('js/admin/icheck.min.js') }}"></script>-->
<script src="{{ asset('js/admin/ajax.js') }}"></script>